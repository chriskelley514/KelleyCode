import java.util.Scanner;

class SSNValidator {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Prompt the user to enter a Social Security number
        System.out.print("Enter a SSN: ");
        String ssn = scanner.nextLine();

        // Check if the entered SSN is valid
        if (isValidSSN(ssn)) {
            System.out.println(ssn + " is a valid social security number");
        } else {
            System.out.println(ssn + " is an invalid social security number");
        }

        scanner.close();
    }

    // Method to validate the SSN format
    public static boolean isValidSSN(String ssn) {
        // Regular expression to match the format DDD-DD-DDDD
        String regex = "\\d{3}-\\d{2}-\\d{4}";

        // Check if the SSN matches the regular expression
        return ssn.matches(regex);
    }
}
