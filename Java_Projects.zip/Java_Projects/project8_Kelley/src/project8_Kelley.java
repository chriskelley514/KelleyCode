import java.util.Random;
import java.util.Scanner;

class ArrayLookup {
    public static void main(String[] args) {
        Random random = new Random();
        int[] numbers = new int[100];

        // Populate the array with random integers
        for (int i = 0; i < numbers.length; i++) {
            numbers[i] = random.nextInt(1000); // Random number between 0 and 999
        }

        try (Scanner scanner = new Scanner(System.in)) {
            System.out.print("Enter an array index (0-99): ");
            int index = scanner.nextInt();

            // Display the element at the provided index
            System.out.println("Element at index " + index + ": " + numbers[index]);
        } catch (ArrayIndexOutOfBoundsException e) {
            System.out.println("Out of Bounds.");
        }
    }
}
