import java.util.ArrayList;
import java.util.Collections;
import java.util.Scanner;

// Class containing a method to sort an ArrayList
class SortArrayList {
    // Generic method to sort an ArrayList
    public static <E extends Comparable<E>> void sort(ArrayList<E> list) {
        Collections.sort(list); // Sort the list
    }
}
// Class to test the sorting method
class TestSortArrayList {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        ArrayList<Integer> list = new ArrayList<>();

        // Prompt the user to enter 10 integers
        System.out.println("Enter 10 integers:");
        for (int i = 0; i < 10; i++) {
            System.out.print("Enter integer " + (i + 1) + ": ");
            list.add(scanner.nextInt());
        }

        SortArrayList.sort(list); // Sort the list

        // Display the sorted list
        System.out.println("Sorted list in increasing order:");
        for (int num : list) {
            System.out.print(num + " ");
        }
    }
}
