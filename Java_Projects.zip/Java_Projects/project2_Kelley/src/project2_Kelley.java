import java.util.Scanner;
import java.util.Vector;

class PalindromeChecker {

    // Recursive method to check if a string is a palindrome
    public static boolean isPalindrome(String s) {
        // Base cases
        if (s.length() <= 1) {
            return true;
        }

        // Check if first and last characters are the same
        if (s.charAt(0) != s.charAt(s.length() - 1)) {
            return false;
        }

        // Recursive call without the first and last characters
        return isPalindrome(s.substring(1, s.length() - 1));
    }

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        Vector<String> strings = new Vector<>(10);

        // Prompt the user for 10 strings
        System.out.println("Please enter 10 strings:");
        for (int i = 0; i < 10; i++) {
            System.out.print("String " + (i + 1) + ": ");
            strings.add(scanner.nextLine());
        }

        // Loop through the vector and check each string for palindrome
        for (String s : strings) {
            boolean result = isPalindrome(s);
            System.out.println("The string \"" + s + "\" is " + (result ? "" : "not ") + "a palindrome.");
        }

        scanner.close();
    }
}
