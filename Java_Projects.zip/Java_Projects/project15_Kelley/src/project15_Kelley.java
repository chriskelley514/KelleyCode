import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.io.IOException;

public class project15_Kelley {

    public static void main(String[] args) {
        // Database URL
        String dbUrl = "jdbc:derby:Books;create=true";

        // File path for the SQL query file
        String filePath = "D:\\Java_Projects\\project15_Kelley\\query\\booksQuery.sql";

        try {
            // Load the SQL query from the file
            String query = new String(Files.readAllBytes(Paths.get(filePath)));

            // Load the JavaDB driver
            Class.forName("org.apache.derby.jdbc.EmbeddedDriver");

            // Connect to the database
            Connection connection = DriverManager.getConnection(dbUrl);

            // Create a statement
            Statement statement = connection.createStatement();

            // Execute the query
            ResultSet resultSet = statement.executeQuery(query);

            // Process the result set
            while (resultSet.next()) {
                String firstName = resultSet.getString("FirstName");
                String lastName = resultSet.getString("LastName");
                System.out.println("Author: " + firstName + " " + lastName);
            }

            // Close the resources
            resultSet.close();
            statement.close();
            connection.close();

            // Shutdown the database
            try {
                DriverManager.getConnection("jdbc:derby:;shutdown=true");
            } catch (SQLException e) {
                if (!e.getSQLState().equals("XJ015")) {
                    throw e;
                }
            }

        } catch (ClassNotFoundException e) {
            System.err.println("Failed to load the JavaDB driver.");
            e.printStackTrace();
        } catch (SQLException e) {
            System.err.println("Database access error:");
            e.printStackTrace();
        } catch (IOException e) {
            System.err.println("Failed to read the SQL file:");
            e.printStackTrace();
        }
    }
}
