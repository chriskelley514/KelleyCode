SELECT FirstName, LastName
FROM Authors
WHERE LastName = 'Deitel'
