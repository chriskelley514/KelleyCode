import java.io.*;
import java.util.Random;

class project9_Kelley {
    public static void main(String[] args) {
        // Define the file path
        File file = new File("Exercise17_02.dat");

        // Writing 100 random integers to the file using binary I/O, overwriting existing content
        try (DataOutputStream output = new DataOutputStream(new FileOutputStream(file, false))) { // false to overwrite
            Random random = new Random(); // Random number generator

            // Write 100 integers to the file
            for (int i = 0; i < 100; i++) {
                output.writeInt(random.nextInt(1000)); // Generate numbers up to 1000
            }
        } catch (IOException ex) {
            System.out.println("Error writing to file: " + ex.getMessage());
        }

        // Reading integers from the file and calculating the sum
        int sum = 0;
        try (DataInputStream input = new DataInputStream(new FileInputStream(file))) {

            // Continue reading and summing integers while there are bytes to read
            while (input.available() > 0) {
                sum += input.readInt();
            }

        } catch (IOException ex) {
            System.out.println("Error reading file: " + ex.getMessage());
        }

        // Output the sum
        System.out.println("The sum of the integers is: " + sum);
    }
}
