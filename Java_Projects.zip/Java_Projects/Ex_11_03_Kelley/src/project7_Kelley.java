import java.util.Date;

/**
 * The Account class models a general bank account.
 */
class Account {
    private final int accountNumber;
    protected double balance;
    double annualInterestRate;
    private final Date dateCreated;

    // Constructor to initialize the account
    public Account(int accountNumber, double balance, double annualInterestRate) {
        this.accountNumber = accountNumber;
        this.balance = balance;
        this.annualInterestRate = annualInterestRate;
        this.dateCreated = new Date();  // Sets the account creation date to the current time
    }

    // Method to deposit funds into the account
    public void deposit(double amount) {
        this.balance += amount;
    }

    // Method to withdraw funds from the account
    public void withdraw(double amount) {
        if (amount <= balance) {
            balance -= amount;
        } else {
            System.out.println("Insufficient funds");
        }
    }

    // Method to return a string representation of the account details
    public String toString() {
        return "Account Number: " + accountNumber + "\nBalance: " + balance +
                "\nAnnual Interest Rate: " + annualInterestRate + "\nDate Created: " + dateCreated;
    }
}

/**
 * The SavingsAccount class models a savings account.
 * Withdrawals beyond the current balance are not allowed.
 */
class SavingsAccount extends Account {
    public SavingsAccount(int accountNumber, double balance, double annualInterestRate) {
        super(accountNumber, balance, annualInterestRate);
    }

    @Override
    public void withdraw(double amount) {
        if (amount > balance) {
            System.out.println("Savings account cannot be overdrawn.");
        } else {
            super.withdraw(amount);
        }
    }

    @Override
    public String toString() {
        return "Savings " + super.toString();
    }
}

/**
 * The CheckingAccount class models a checking account with an overdraft limit.
 */
class CheckingAccount extends Account {
    private final double overdraftLimit;

    public CheckingAccount(int accountNumber, double balance, double annualInterestRate, double overdraftLimit) {
        super(accountNumber, balance, annualInterestRate);
        this.overdraftLimit = overdraftLimit;
    }

    @Override
    public void withdraw(double amount) {
        if (amount > balance + overdraftLimit) {
            System.out.println("Exceeded overdraft limit.");
        } else {
            balance -= amount;  // Allow the balance to go negative up to the overdraft limit.
        }
    }

    @Override
    public String toString() {
        return "Checking " + super.toString() + "\nOverdraft Limit: " + overdraftLimit;
    }
}

/**
 * A test program to demonstrate the usage of Account, SavingsAccount, and CheckingAccount.
 */
class TestBankAccounts {
    public static void main(String[] args) {
        SavingsAccount savAcc = new SavingsAccount(102, 1500, 0.04);
        CheckingAccount chkAcc = new CheckingAccount(103, 500, 0.03, 200);
        Account acc = new Account(101, savAcc.balance + chkAcc.balance, savAcc.annualInterestRate + chkAcc.annualInterestRate);

        System.out.println(acc);
        System.out.println("\n");
        System.out.println(savAcc);
        System.out.println("\n");
        System.out.println(chkAcc);
        System.out.println("\n");

        // Savings tests
        savAcc.deposit(500); // This should be successful
        System.out.println("Deposit of 500 successful. Savings balance is now: " + savAcc.balance);
        savAcc.withdraw(1000); // This should be successful
        System.out.println("Withdraw of 1000 successful. Savings balance is now: " + savAcc.balance);
        savAcc.withdraw(1500); // This should fail due to insufficient funds.
        System.out.println("\n");

        // Checking tests
        chkAcc.deposit(500); // This should be successful
        System.out.println("Deposit successful. Checking balance is now: " + chkAcc.balance);
        chkAcc.withdraw(800); // This should be successful
        System.out.println("Withdrawal successful. Checking balance is now: " + chkAcc.balance);
        chkAcc.withdraw(400);  // This should succeed using the overdraft.
        System.out.println("Withdrawal successful. Checking balance is now: " + chkAcc.balance);
        chkAcc.withdraw(200); // This should fail due to exceeding overdraft
    }
}
