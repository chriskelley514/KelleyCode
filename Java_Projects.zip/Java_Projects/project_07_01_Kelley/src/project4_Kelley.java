import java.util.Scanner;

class  GradeAssigner {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Prompting the user to enter the total number of students
        System.out.print("Enter the total number of students: ");
        int numberOfStudents = scanner.nextInt();

        // Array to store the scores
        int[] scores = new int[numberOfStudents];

        // Prompting the user to enter the scores
        System.out.println("Enter the scores of each student:");
        for (int i = 0; i < numberOfStudents; i++) {
            scores[i] = scanner.nextInt();
        }

        // Determining the best score
        int bestScore = findBestScore(scores);

        // Displaying grades for each student
        System.out.println("Here are the grades:");
        for (int i = 0; i < numberOfStudents; i++) {
            System.out.println("Student " + (i + 1) + " score is " + scores[i] + " and grade is " + assignGrade(scores[i], bestScore));
        }

        scanner.close();
    }

    // Method to find the best score
    private static int findBestScore(int[] scores) {
        int best = 0;
        for (int score : scores) {
            if (score > best) {
                best = score;
            }
        }
        return best;
    }

    // Method to assign grades based on the score and the best score
    private static String assignGrade(int score, int bestScore) {
        if (score >= bestScore - 10) {
            return "A";
        } else if (score >= bestScore - 20) {
            return "B";
        } else if (score >= bestScore - 30) {
            return "C";
        } else if (score >= bestScore - 40) {
            return "D";
        } else {
            return "F";
        }
    }
}
