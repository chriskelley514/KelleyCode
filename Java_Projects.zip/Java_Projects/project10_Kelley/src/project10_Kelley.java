import javax.swing.*;
import java.awt.*;
import java.util.Random;

//Define the main class extending JFrame
class Exercise14_07 extends JFrame {
    // Constructor for the class
    public Exercise14_07() {
        // Set the layout of the frame to a 10X10 grid
        setLayout(new GridLayout(10, 10));

        // Create an instance of random to generate random numbers
        Random random = new Random();

        // Loop to create 100 JTextFields
        for (int i = 0; i < 100; i++) {
            // Create a new JTextField
            JTextField textField = new JTextField();
            // Set the text alignment to center
            textField.setHorizontalAlignment(JTextField.CENTER);
            // Set the text of the JTextField to a random 0 or 1
            textField.setText(String.valueOf(random.nextInt(2)));
            // Make the JTextField non-editable
            textField.setEditable(false);
            // Add the JTextField to the frame
            add(textField);
        }
    }
    // Main method to run the application
    public static void main(String[] args) {
        // Create an instance of the Exercise14_07 frame
        Exercise14_07 frame = new Exercise14_07();
        // Set the title of the frame
        frame.setTitle("Exercise14_07");
        // Set the size of the frame
        frame.setSize(400, 400);
        // Center the frame on the screen
        frame.setLocationRelativeTo(null);
        // Set the default close operation to exit the application
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        // Make the frame visible
        frame.setVisible(true);
    }
}
