import java.util.Scanner;

class CylinderVolumeCalculator {
    public static void main(String[] args) {
        // Create a Scanner object for reading input
        Scanner input = new Scanner(System.in);

        // Prompt the user to enter the radius and length of the cylinder in one line
        System.out.print("Enter the radius and length of the cylinder: ");
        String line = input.nextLine();

        // Split the input line into parts
        String[] parts = line.split(" ");

        // Parse the radius and length from the input parts
        double radius = Double.parseDouble(parts[0]);
        double length = Double.parseDouble(parts[1]);

        // Compute the area of the cylinder's base
        double area = Math.PI * Math.pow(radius, 2);

        // Compute the volume of the cylinder
        double volume = area * length;

        // Display the results
        System.out.printf("The area of the cylinder's base is: %.7f\n", area);
        System.out.printf("The volume of the cylinder is: %.8f\n", volume);

        // Close the scanner
        input.close();
    }
}
