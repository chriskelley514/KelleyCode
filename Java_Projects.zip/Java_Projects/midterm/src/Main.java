class Test {
    public static void main(String[] args) {
        int x = 1;
        int y = x + x++;
        System.out.println("y is " + y);
    }
}