class SeriesSum {

    // Recursive method to compute the series sum
    public static double computeSeries(int i) {
        // Base case
        if (i == 1) {
            return 1.0 / 3;
        }
        // Recursive case
        return (double) i / (2 * i + 1) + computeSeries(i - 1);
    }
    public static void main(String[] args) {
        // Test the method for i = 1, 2, ..., 10
        for (int i = 1; i <= 10; i++) {
            System.out.printf("m(%d) = %.6f%n", i, computeSeries(i));
        }
    }
}
