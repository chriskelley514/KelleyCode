import java.util.Date;

class Account {
    private int id = 0;
    private double balance = 0;
    private static double annualInterestRate = 0; // Static since all accounts share the same rate
    private Date dateCreated;

    // No-arg constructor
    public Account() {
        dateCreated = new Date();
    }

    // Constructor with specified id and initial balance
    public Account(int id, double balance) {
        this();
        this.id = id;
        this.balance = balance;
    }

    // Accessor methods
    public int getId() {
        return id;
    }

    public double getBalance() {
        return balance;
    }

    public static double getAnnualInterestRate() {
        return annualInterestRate;
    }

    public Date getDateCreated() {
        return dateCreated;
    }

    // Mutator methods
    public void setId(int id) {
        this.id = id;
    }

    public static void setAnnualInterestRate(double rate) {
        annualInterestRate = rate;
    }

    // Returns the monthly interest rate
    public double getMonthlyInterestRate() {
        return (annualInterestRate / 12) / 100;
    }

    // Returns the monthly interest amount
    public double getMonthlyInterest() {
        return balance * getMonthlyInterestRate();
    }

    // Method to withdraw amount from balance
    public void withdraw(double amount) {
        balance -= amount;
    }

    // Method to deposit amount to balance
    public void deposit(double amount) {
        balance += amount;
    }
}

class TestAccount {
    public static void main(String[] args) {
        Account account = new Account(1122, 20000);
        Account.setAnnualInterestRate(4.5);

        account.withdraw(2500);
        account.deposit(3000);

        System.out.println("Balance: $" + account.getBalance());
        System.out.println("Monthly Interest: $" + account.getMonthlyInterest());
        System.out.println("Account Creation Date: " + account.getDateCreated());
    }
}
