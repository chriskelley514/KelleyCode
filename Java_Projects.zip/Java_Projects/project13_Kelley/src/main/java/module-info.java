module com.example.project13_kelley {
    requires javafx.controls;
    requires javafx.fxml;


    opens com.example.project13_kelley to javafx.fxml;
    exports com.example.project13_kelley;
}