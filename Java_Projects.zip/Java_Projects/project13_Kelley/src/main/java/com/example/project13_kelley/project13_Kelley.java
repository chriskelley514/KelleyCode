package com.example.project13_kelley;

import javafx.application.Application;
import javafx.application.Platform;
import javafx.scene.Scene;
import javafx.scene.control.TextArea;
import javafx.scene.layout.BorderPane;
import javafx.stage.Stage;

public class project13_Kelley extends Application {
    // TextArea for displaying output
    private final TextArea textArea = new TextArea();

    @Override
    public void start(Stage primaryStage) {
        // Set up the primary layout and scene
        BorderPane pane = new BorderPane();
        textArea.setWrapText(true); // Wrap text within the TextArea
        pane.setCenter(textArea); // Place TextArea in the center of the BorderPane

        Scene scene = new Scene(pane, 400, 200); // Create a scene with specific dimensions
        primaryStage.setTitle("Exercise 32_01"); // Set window title
        primaryStage.setScene(scene); // Assign scene to the stage
        primaryStage.show(); // Display the stage

        // Start threads for concurrent execution
        new Thread(new PrintChar('a', 100)).start(); // Print 'a' 100 times
        new Thread(new PrintChar('b', 100)).start(); // Print 'b' 100 times
        new Thread(new PrintNum(100)).start(); // Print numbers from 1 to 100
    }

    // Runnable class to print a character multiple times
    class PrintChar implements Runnable {
        private final char charToPrint; // Character to print
        private final int times; // Number of times to print

        public PrintChar(char c, int t) {
            charToPrint = c;
            times = t;
        }

        @Override
        public void run() {
            for (int i = 0; i < times; i++) {
                // Ensure updates to TextArea are done on JavaFX Application Thread
                Platform.runLater(() -> textArea.appendText(charToPrint + ""));
            }
        }
    }
    // Runnable class to print numbers from 1 to a specified number
    class PrintNum implements Runnable {
        private final int lastNum; // Last number to print

        public PrintNum(int n) {
            lastNum = n;
        }

        @Override
        public void run() {
            for (int i = 1; i <= lastNum; i++) {
                int finalI = i; // Need a final copy for lambda expression
                // Ensure updates to TextArea are done on JavaFX Application Thread
                Platform.runLater(() -> textArea.appendText(finalI + ""));
            }
        }
    }

    public static void main(String[] args) {
        launch(args); // Launch the JavaFX application
    }
}
