// Changes login label from email to username
/*
$(document).ready(function(){
  if(window.location.pathname.search('login')){
    if ($('#f1_container').length == 0) {  // not a mobile browser
      var sp = $('#login_form label[for=pseudonym_session_unique_id]>span');
    sp.text('B Number');    
    } else {    // mobile browser
      $('input[name="pseudonym_session[unique_id]"]').attr("placeholder", "B Number");
    }
  }
  if(window.location.pathname.search('enroll')) {
    $('label[for="student_email"]').text("B Number");
    $('p:contains("Please enter your email and password")').text("Please enter your B Number and password");
  }
});
*/

/**
 * JQuery is the javascript library used in many places across canvas.  
 *
 * This script describes how you would change the "I forgot my password" text on the Canvas
 * Login page.    
 *
 * When implementing this script, replace <replacement> with the text you want to appear.
 * For example, you may want to have that text be "Help me find my password" rather than "I forgot my password".  
 *
 *
 *
 **/
$(document).ready(function(){
  if(window.location.pathname.search('login')){
    $('#login_forgot_password').text('Enter your B Number to login. First time logging into Canvas or forgot your password? Click this link to get an email at your Titans email to setup up your password.');
  }

  /*
   * Use this to remove the Delete Course, Conclude Coures, and Reset Course Content 
   * Buttons from Canvas if you are a teacher
   */

  //This hides the buttons
   // Checks that current user role is is a teacher, Admins can see the buttons
   // 
  /**old javascript removed 8/9/2017 - JoseG
  if($.inArray('admin',ENV['current_user_roles']) == -1
      && $.inArray('teacher',ENV['current_user_roles']) > -1) {
    $('a.btn.button-sidebar-wide.delete_course_link').hide();
    $('a.btn.button-sidebar-wide.reset_course_content_button').hide();
    $("a:contains('Conclude this Course')").hide();
  }
  **/
  if ($.inArray('admin', ENV['current_user_roles']) == -1 && $.inArray('teacher', ENV['current_user_roles']) > -1) {
  $('[href*="confirm_action?event=delete"]').hide();
  $('[href*="confirm_action?event=conclude"]').hide();
  $('.reset_course_content_button').hide();
  }

  //
  //Javascript for LINCCWeb Rich Content URLs.
  $('body').on('click', 'a.external', function(event){
    url = $(this).attr('href');
    if (url.indexOf('linccweb=1') > -1) {
      event.preventDefault();
      url = url + "&canvas_user_id=" + ENV.current_user_id
      window.open(url);
    }
  });
});

/** Ally javascript **/
window.ALLY_CFG = {
    'baseUrl': 'https://prod.ally.ac',
    'clientId': 9532,
    'lti13Id': '310000000000581'
};
$.getScript(ALLY_CFG.baseUrl + '/integration/canvas/ally.js');