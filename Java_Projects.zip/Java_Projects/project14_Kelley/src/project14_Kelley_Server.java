import java.io.*;
import java.net.*;

public class project14_Kelley_Server {
    public static void main(String[] args) {
        // Initialize the server socket on port 12345
        try (ServerSocket serverSocket = new ServerSocket(12345)) {
            System.out.println("Server is running and waiting for a client connection...");

            // Continuously listen for client connection
            while (true) {
                // Accept an incoming client connection
                try (Socket socket = serverSocket.accept();
                     // Create BufferedReader to read data from client
                     BufferedReader in = new BufferedReader(new InputStreamReader(socket.getInputStream()));
                     // Create PrintWriter to send data back to client
                     PrintWriter out = new PrintWriter(socket.getOutputStream(), true)) {

                    System.out.println("Client connected.");

                    // Read loan information from client
                    double annualInterestRate = Double.parseDouble(in.readLine());
                    int numberOfYears = Integer.parseInt(in.readLine());
                    double loanAmount = Double.parseDouble(in.readLine());

                    // Calculate monthly payment and total payment
                    double monthlyPayment = calculateMonthlyPayment(annualInterestRate, numberOfYears, loanAmount);
                    double totalPayment = monthlyPayment * numberOfYears * 12;

                    // Send the results back to the client
                    out.println("Monthly Payment: " + String.format("%.2f", monthlyPayment));
                    out.println("Total Payment: " + String.format("%.2f", totalPayment));
                } catch (IOException e) {
                    // Handle client-related IO exceptions
                    System.err.println("Error handling client: " + e.getMessage());
                }
            }
        } catch (IOException e) {
            // Handle server-related IO exceptions
            System.err.println("Server error: " + e.getMessage());
        }
    }

    /**
     *  Calculates the monthly payment based on the loan parameters
     *
     * @param annualInterestRate is the annual interest rate in percent
     * @param numberOfYears is the number of years for the loan
     * @param loanAmount is the total loan amount
     * @return is the monthly payment
     */

    public static double calculateMonthlyPayment(double annualInterestRate, int numberOfYears, double loanAmount) {
        double monthlyInterestRate = annualInterestRate / 100 / 12;
        int numberOfPayments = numberOfYears * 12;
        return (loanAmount * monthlyInterestRate) / (1 - Math.pow(1 + monthlyInterestRate, -numberOfPayments));
    }
}
