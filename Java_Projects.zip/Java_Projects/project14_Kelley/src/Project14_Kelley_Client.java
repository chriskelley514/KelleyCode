import java.io.*;
import java.net.*;
import java.util.Scanner;

public class Project14_Kelley_Client {
    public static void main(String[] args) {
        // Connect to server
        try (Socket socket = new Socket("localhost", 12345);
             BufferedReader in = new BufferedReader(new InputStreamReader(socket.getInputStream()));
             PrintWriter out = new PrintWriter(socket.getOutputStream(), true);
             Scanner scanner = new Scanner(System.in)) {

            System.out.println("Connected to the server.");

            // Collect loan information from user
            System.out.print("Enter annual interest rate: ");
            double annualInterestRate = scanner.nextDouble();
            System.out.print("Enter number of years: ");
            int numberOfYears = scanner.nextInt();
            System.out.print("Enter loan amount: ");
            double loanAmount = scanner.nextDouble();

            // Send loan information to server
            out.println(annualInterestRate);
            out.println(numberOfYears);
            out.println(loanAmount);

            // Receive and display results from server
            System.out.println(in.readLine()); // Monthly Payment
            System.out.println(in.readLine()); // Total Payment
        } catch (IOException e) {
            System.err.println("Client error: " + e.getMessage());
        }
    }
}
