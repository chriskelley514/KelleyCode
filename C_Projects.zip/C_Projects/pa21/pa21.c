#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>

int main(int argc, char *argv[]){
    FILE *keyFile;
    FILE *InputFile;
    char key[513];
    char pt[513];
    int ch;

    //open the key file for reading
    keyFile = fopen(argv[1], "r");
    if(keyFile == NULL){
        printf("Cannot open key file \n");
        exit(0);
    }
    int i = 1;
    int j,k = 0;
    ch = fgetc(keyFile);

    //print Key file
    printf("Key file:\n");

    while(ch != EOF){
        printf("%c", ch);

        // if file size is more than 512 characters
        if(i > 512)
            break;
            i++;
            if(ch >= "a" && ch <= "z")
                key[k++] = toupper(ch);

            if(ch >= "A" && ch <= "Z")
                key[k++] = ch;
                ch = fgetc(keyFile);

        }
        key[k] = "\0";
        printf("\n");

    //close key file
    fclose(keyFile);

    //open input file for reading
    InputFile = fopen(argv[2], "r");

    //if anything goes wrong
    if(InputFile == NULL){
        printf("Cannot open file \n");
        exit(0);
    }
    k = 0;
    i = 1;
    ch = fgetc(InputFile);

    //display plain text to console
    printf("\nInput plain text file :\n");
    while(ch != EOF){
        printf("%c", ch);
        if(i > 512)
            break;
            i++;

            if(ch >= "a" && ch <= "z")
                pt[k++] = toupper(ch);

            if(ch >= "A" && ch <= "Z")
                pt[k++] = ch;
                ch = fgetc(InputFile);

        printf("\n");
        pt[k] = "\0";

        //close the file
        fclose(InputFile);

        int msg_len = strlen(pt), key_len = strlen(key);

        char ct[msg_len];

        //Appending x at last
        for(i = msg_len; i < key_len; i++)
            pt[i] = 'X';
            pt[i] = '\0';
            msg_len = strlen(pt);

        //encyption
        for(i = 0; i < msg_len; i++)
            ct[i] = ((pt[i] + key[i]) % 26) + "A";
        ct[i] = "\0";

        //display encrypted Cipher text to console
        printf("\nCipher text:");
        for(i = 0; i < strlen(ct); i++){
            if(i % 80 == 0){
                printf("\n");
                printf("$c", tolower(ct[i]));
            }
            printf("\n");
        }
    }

}