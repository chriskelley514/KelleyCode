#include <iostream>
#include <vector>
#include <random>

// Circle class definition
class Circle {
public:
    int radius;

    explicit Circle(int r) : radius(r) {}

    bool operator<(const Circle& other) const {
        return radius < other.radius;
    }
};

// Insertion sort function template
template <typename Comparable>
void insertionSort(std::vector<Comparable>& a) {
    for (int p = 1; p < a.size(); ++p) {
        Comparable tmp = std::move(a[p]);
        int j;
        for (j = p; j > 0 && tmp < a[j - 1]; --j) {
            a[j] = std::move(a[j - 1]);
        }
        a[j] = std::move(tmp);
    }
}

// Function to generate a vector of Circle objects with random radii
std::vector<Circle> generateRandomCircles(int numCircles, int minRadius, int maxRadius) {
    std::vector<Circle> circles;
    std::random_device rd;
    std::mt19937 gen(rd());
    std::uniform_int_distribution<> dis(minRadius, maxRadius);

    for (int i = 0; i < numCircles; ++i) {
        circles.emplace_back(dis(gen));
    }
    return circles;
}

// Function to display a vector of Circle objects
void displayCircles(const std::vector<Circle>& circles) {
    for (const auto& circle : circles) {
        std::cout << circle.radius << " ";
    }
    std::cout << std::endl;
}

int main() {
    const int numCircles = 50;
    const int minRadius = 1;
    const int maxRadius = 100;

    // Generate random circles
    std::vector<Circle> circles = generateRandomCircles(numCircles, minRadius, maxRadius);

    // Display unsorted circles
    std::cout << "Unsorted Circles:" << std::endl;
    displayCircles(circles);

    // Sort the circles using insertion sort
    insertionSort(circles);

    // Display sorted circles
    std::cout << "Sorted Circles:" << std::endl;
    displayCircles(circles);

    return 0;
}
