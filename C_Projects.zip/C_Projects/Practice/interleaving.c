#include <stdio.h>
#include <stdbool.h>
#include <math.h>

#define TRUE 1;
#define FALSE 0;

bool isInterleave(char * s1[], char * s2[], char * s3[]);


void main(void){
int a;
int b;
int c;
isInterleave(a,b,c);

return 0;

}

bool isInterleave(char * s1[], char * s2[], char * s3[]){
    char a;
    char b;
    char c;
    *s1 = a;
    *s2 = b;
    *s3 = c;
    printf("What are the letters for s1?");
    scanf("%c", a);
    printf("What are the letters for s2?");
    scanf("%c", b);
    if (abs(a - b) <= 1){
        c = a + b;
        return true;
        printf("true");
    }
    else{
        return false;
        printf("false");
    }
}
