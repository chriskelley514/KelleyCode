#include <iostream>
#include <vector>
#include <string>

// Recursive function to check if a string is a palindrome
bool isPalindrome(const std::string& str, int start, int end) {
    // Base case: If the start index is greater than or equal to the end index, it's a palindrome
    if (start >= end) {
        return true;
    }
    // Check if the characters at the start and end indices are the same
    if (str[start] != str[end]) {
        return false;
    }
    // Recursive call: Move towards the middle of the string
    return isPalindrome(str, start + 1, end - 1);
}

// Overloaded function to simplify the call to the recursive function
bool isPalindrome(const std::string& str) {
    // Initial call to the recursive function with start index 0 and end index str.length() - 1
    return isPalindrome(str, 0, static_cast<int>(str.length()) - 1);
}

int main() {
    std::vector<std::string> strings; // Vector to store the input strings
    std::string input;                // Temporary string to hold user input

    std::cout << "Enter 10 strings:" << std::endl;
    // Loop to read 10 strings from the user
    for (int i = 0; i < 10; ++i) {
        std::getline(std::cin, input); // Read a string from the user
        strings.push_back(input);      // Add the string to the vector
    }

    // Loop through each string in the vector
    for (const auto& str : strings) {
        // Check if the current string is a palindrome using the recursive function
        if (isPalindrome(str)) {
            std::cout << "\"" << str << "\" is a palindrome." << std::endl;
        } else {
            std::cout << "\"" << str << "\" is not a palindrome." << std::endl;
        }
    }

    return 0; // Successful program termination
}
