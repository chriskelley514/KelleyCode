#include <stdio.h>
#include <stdlib.h>

char *fruits[] = {"D", "D#", "F", "G", "G#", "A#", "C"};
int count = 0;
void comb(char **set, int nset, int start, int depth);

int main() {
    int n = sizeof(fruits) / sizeof(fruits[0]);
    char *set[3];
    comb(set, n, 0, 0);

    return 0;
}

void comb(char **set, int n, int start, int depth){
    if(depth == 10){
        printf("%d.", ++count);
        for(int i = 0; i < 6; i++){
            printf(" %s", set[i]);
        }
        printf("\n");
        return;
    }

    for(; start < n; start++){
        set[depth] = fruits[start];
        comb(set, n, start + 1, depth + 1);
    }
}
