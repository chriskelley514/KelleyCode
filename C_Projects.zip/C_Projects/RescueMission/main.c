#include <stdio.h>
#include <stdlib.h>

//2 ints S and L
//Wake - The Ship has already passed
//No wake - the ship has not passed
//Boat! - the ship was captured in the photo

int main() {
    char userInput[100 + 1]; //user input
    int S; //Knots
    int L; //Coordinates
    int search; //binary search

    scanf("%d %d", &S, &L);

    do {
        fgets(userInput, 100 + 1, stdin);

    }while(userInput != );

    return 0;
}
