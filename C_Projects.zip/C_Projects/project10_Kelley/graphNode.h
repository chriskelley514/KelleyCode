#include <iostream>
#include <vector>

class GraphNode {
public:
    int pointNum;
    std::vector<GraphNode*> connectedNodes;

    explicit GraphNode(int num) : pointNum(num) {}

    void addConnection(GraphNode* node) {
        connectedNodes.push_back(node);
    }
};
