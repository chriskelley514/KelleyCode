#include <iostream>
#include <vector>
#include "GraphNode.h"
#include "graphClass.h"

int main() {
    int n;
    std::cout << "Enter the number of nodes: ";
    std::cin >> n;

    std::vector<std::vector<int>> adjacencyMatrix(n, std::vector<int>(n));

    std::cout << "Enter the adjacency matrix:\n";
    for (int i = 0; i < n; ++i) {
        for (int j = 0; j < n; ++j) {
            std::cin >> adjacencyMatrix[i][j];
        }
    }

    Graph graph;
    graph.buildGraph(n, adjacencyMatrix);
    graph.displayGraph();

    return 0;
}
