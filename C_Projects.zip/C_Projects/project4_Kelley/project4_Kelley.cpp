#include <iostream>
#include <chrono>

using namespace std;
using namespace std::chrono;

int method_1(int n) {
    int sum = 0;
    for (int i = 0; i < n; ++i)
        ++sum;
    return sum;
}

int method_2(int n) {
    int sum = 0;
    for (int i = 0; i < n; ++i)
        for (int j = 0; j < n; ++j)
            ++sum;
    return sum;
}

int method_3(int n) {
    int sum = 0;
    for (int i = 0; i < n; ++i)
        for (int j = 0; j < n * n; ++j)
            ++sum;
    return sum;
}

int method_4(int n) {
    int sum = 0;
    for (int i = 0; i < n; ++i)
        for (int j = 0; j < i; ++j)
            ++sum;
    return sum;
}

int method_5(int n) {
    int sum = 0;
    for (int i = 0; i < n; ++i)
        for (int j = 0; j < i * i; ++j)
            for (int k = 0; k < j; ++k)
                ++sum;
    return sum;
}

int method_6(int n) {
    int sum = 0;
    for (int i = 1; i < n; ++i)
        for (int j = 1; j < i * i; ++j)
            if (j % i == 0)
                for (int k = 0; k < j; ++k)
                    ++sum;
    return sum;
}

int main() {
    int n = 10; // Increase the value of n

    auto start = steady_clock::now();
    cout << "Method 1: " << method_1(n) << endl;
    auto stop = steady_clock::now();
    auto duration_1 = duration_cast<duration<double>>(stop - start);
    cout << "Method 1 Runtime: " << duration_1.count() << " seconds" << endl;

    start = steady_clock::now();
    cout << "Method 2: " << method_2(n) << endl;
    stop = steady_clock::now();
    auto duration_2 = duration_cast<duration<double>>(stop - start);
    cout << "Method 2 Runtime: " << duration_2.count() << " seconds" << endl;

    start = steady_clock::now();
    cout << "Method 3: " << method_3(n) << endl;
    stop = steady_clock::now();
    auto duration_3 = duration_cast<duration<double>>(stop - start);
    cout << "Method 3 Runtime: " << duration_3.count() << " seconds" << endl;

    start = steady_clock::now();
    cout << "Method 4: " << method_4(n) << endl;
    stop = steady_clock::now();
    auto duration_4 = duration_cast<duration<double>>(stop - start);
    cout << "Method 4 Runtime: " << duration_4.count() << " seconds" << endl;

    start = steady_clock::now();
    cout << "Method 5: " << method_5(n) << endl;
    stop = steady_clock::now();
    auto duration_5 = duration_cast<duration<double>>(stop - start);
    cout << "Method 5 Runtime: " << duration_5.count() << " seconds" << endl;

    start = steady_clock::now();
    cout << "Method 6: " << method_6(n) << endl;
    stop = steady_clock::now();
    auto duration_6 = duration_cast<duration<double>>(stop - start);
    cout << "Method 6 Runtime: " << duration_6.count() << " seconds" << endl;

    return 0;
}
