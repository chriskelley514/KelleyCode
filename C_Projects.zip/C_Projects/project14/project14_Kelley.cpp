#include <vector>
#include <iostream>
#include <memory>
#include <queue>
#include <stack>

// Class representing a single node in the graph
class GraphNode {
public:
    int pointNum; // Node identifier
    std::vector<GraphNode*> connectedNodes; // List of nodes this node is connected to

    // Constructor to initialize the node with a given number
    explicit GraphNode(int num) : pointNum(num), visited(false) {}

    // Add a connection from this node to another node
    void addConnection(GraphNode* node) {
        connectedNodes.push_back(node);
    }

    // Check if the node has been visited
    bool isVisited() const {
        return visited;
    }

    // Set the visited status of the node
    void setVisited(bool status) {
        visited = status;
    }

private:
    bool visited; // Track if the node has been visited
};

// Class representing the graph
class Graph {
private:
    std::vector<std::unique_ptr<GraphNode>> nodes; // List of nodes in the graph

public:
    // Create nodes with unique identifiers from 1 to n
    void createNodes(int n) {
        for (int i = 1; i <= n; ++i) {
            nodes.push_back(std::make_unique<GraphNode>(i));
        }
    }

    // Add connections between nodes based on the adjacency matrix
    void addConnections(const std::vector<std::vector<int>>& adjacencyMatrix) {
        for (int i = 0; i < adjacencyMatrix.size(); ++i) {
            for (int j = 0; j < adjacencyMatrix[i].size(); ++j) {
                if (adjacencyMatrix[i][j] == 1) {
                    nodes[i]->addConnection(nodes[j].get());
                }
            }
        }
    }

    // Reset the visited status for all nodes to false
    void resetVisited() {
        for (auto& node : nodes) {
            node->setVisited(false);
        }
    }

    // Perform Depth First Search (DFS) starting from the given node
    void dfs(GraphNode* node) {
        if (node == nullptr) return;

        node->setVisited(true);
        std::cout << node->pointNum << " ";

        for (auto adjacent : node->connectedNodes) {
            if (!adjacent->isVisited()) {
                dfs(adjacent);
            }
        }
    }

    // Perform DFS for the entire graph
    void performDFS() {
        resetVisited();
        for (auto& node : nodes) {
            if (!node->isVisited()) {
                dfs(node.get());
            }
        }
        std::cout << std::endl;
    }

    // Unweighted shortest path using BFS
    void shortestPath(int start, int end) {
        std::vector<int> distances(nodes.size(), -1); // -1 indicates unreachable
        std::vector<int> previous(nodes.size(), -1); // To store the path
        std::queue<int> q;

        distances[start - 1] = 0; // Start node distance is 0
        q.push(start - 1);

        while (!q.empty()) {
            int current = q.front();
            q.pop();
            for (auto& neighbor : nodes[current]->connectedNodes) {
                int neighborIndex = neighbor->pointNum - 1;
                if (distances[neighborIndex] == -1) { // Not visited
                    distances[neighborIndex] = distances[current] + 1;
                    previous[neighborIndex] = current; // Track the path
                    q.push(neighborIndex);

                    if (neighborIndex == end - 1) { // Stop if end node is reached
                        break;
                    }
                }
            }
        }

        // Print the path from start to end node
        if (distances[end - 1] == -1) {
            std::cout << "There is no path from node " << start << " to node " << end << ".\n";
        } else {
            std::cout << "Unweighted shortest path from node " << start << " to node " << end << " is: ";
            std::stack<int> path;
            for (int at = end - 1; at != -1; at = previous[at]) {
                path.push(at);
            }
            while (!path.empty()) {
                std::cout << path.top() + 1 << " ";
                path.pop();
            }
            std::cout << "\n";
            std::cout << "Distance: " << distances[end - 1] + 1 << "\n";
        }
    }
};

int main() {
    int N;
    std::cout << "Enter the number of nodes: ";
    std::cin >> N;

    if (N <= 0) {
        std::cerr << "Number of nodes must be positive.\n";
        return 1;
    }

    // Initialize an adjacency matrix of size NxN
    std::vector<std::vector<int>> adjacencyMatrix(N, std::vector<int>(N));
    std::cout << "Enter the adjacency matrix with a space between connections (0 or 1):\n";
    for (int i = 0; i < N; ++i) {
        for (int j = 0; j < N; ++j) {
            std::cin >> adjacencyMatrix[i][j];
            if (adjacencyMatrix[i][j] != 0 && adjacencyMatrix[i][j] != 1) {
                std::cerr << "Matrix values must be 0 or 1.\n";
                return 1;
            }
        }
    }

    Graph graph; // Create a graph instance
    graph.createNodes(N); // Create nodes for the graph
    graph.addConnections(adjacencyMatrix); // Add connections based on the input matrix

    // Ask the user if they want to perform DFS
    char choice;
    std::cout << "Perform Depth First Search (Y/N)? ";
    std::cin >> choice;
    if (choice == 'Y' || choice == 'y') {
        std::cout << "Depth First Search: ";
        graph.performDFS();
    }

    // Ask the user for the start and end nodes for the shortest path calculation
    int startNode, endNode;
    std::cout << "Enter the starting point(1 index) for unweighted shortest path: ";
    std::cin >> startNode;
    std::cout << "Enter the ending point(1 index) for unweighted shortest path: ";
    std::cin >> endNode;

    // Validate the start and end nodes
    if ((startNode >= 1 && startNode <= N) && (endNode >= 1 && endNode <= N)) {
        graph.shortestPath(startNode, endNode);
    } else {
        std::cerr << "Invalid start or end node.\n";
    }

    return 0;
}
