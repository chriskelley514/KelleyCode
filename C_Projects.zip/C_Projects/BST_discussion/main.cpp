#include <iostream>

struct Node {
    int data;
    Node *left, *right;
    Node(int value) : data(value), left(nullptr), right(nullptr) {}
};

Node* insert(Node* root, int data) {
    if (!root) return new Node(data);
    if (data < root->data) root->left = insert(root->left, data);
    else root->right = insert(root->right, data);
    return root;
}

void inorder(Node* root) {
    if (root) {
        inorder(root->left);
        std::cout << root->data << " ";
        inorder(root->right);
    }
}

int main() {
    Node* root = nullptr; // Initialize root to nullptr for an empty tree
    int elements[] = {50, 30, 70, 20, 40, 60, 80}; // Elements to insert
    for (int value : elements) {
        root = insert(root, value); // Insert elements into the BST
    }
    inorder(root); // Display sorted elements
    return 0;
}
