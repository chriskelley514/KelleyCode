#ifndef GRAPHNODE_H
#define GRAPHNODE_H

class GraphNode {
public:
    int value;
    int topNum;

    explicit GraphNode(int val) : value(val), topNum(0) {}

    void setTopNum(int num) {
        topNum = num;
    }

    [[nodiscard]] int getTopNum() const {
        return topNum;
    }
};

#endif // GRAPHNODE_H
