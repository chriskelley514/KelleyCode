#include <stdio.h>
#include <string.h>
#include <stdlib.h>

void swap(int *, int *);

int *permute(int **, int *, int, int);

int getMin(int **, int *, int , int );

int main(){
    char userInput[100];
    char *token;
    int size;
    int min;

    // taking the size of the array
    scanf("%d", &size);
    getchar();

    // 2D array
    int arr[size][size];

    //permutation array
    int permArr[size];

    for(int i = 0; i < size; i++){
        fgets(userInput, 100, stdin);
        token = strtok(userInput, " ");
        arr[i][0] = atoi(token);

        for(int j = 0; j < size; i++){
            token = strtok(NULL, " ");
            arr[0][j] = atoi(token);
        }
    }

    min = getMin(arr, permArr, 0, size);


    printf("%d", min);

    return 0;
}

void swap(int *x, int *y){
    int temp;
    temp = *x;
    *x = *y;
    *y = temp;
}

int *permute(int **arr, int *permArr, int start, int end){
    int i;

    if(start == end){
        return *permarr;
    }
    else{
        for(i = 1; i <= end; i++){
            swap(i  i+1, **arr, size);
            permute(**arr, permArr, start + 1, end);
            swap((permArr + start), (permArr + i));
        }
    }
}

int getMin(int **arr, int *permArr, int start, int end) {
    int min; // this is the minimum value yet
    int curr;  // stores the current sum of values in the row

    if (curr < min) {
        min = curr;
        curr = 0;
        if (start == end) {
            return min;
        }
    } else {
        for (int i = 0; i < end; i++) {
            permute(**arr, *permArr, start, end);
        }
    }
}